module.exports = {
  siteUrl: process.env.SITE_URL || 'https://abdulrahman.id',
  generateRobotsTxt: true,
}
